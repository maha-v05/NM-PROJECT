import speech_recognition as sr
import pyttsx3

# Initialize text-to-speech engine
engine = pyttsx3.init()

# Simulated appliances
appliances = {
    "light": False,
    "fan": False,
    "tv": False
}

def speak(text):
    engine.say(text)
    engine.runAndWait()

def listen_command():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening for command...")
        r.adjust_for_ambient_noise(source)
        audio = r.listen(source)

    try:
        command = r.recognize_google(audio)
        print("You said:", command)
        return command.lower()
    except sr.UnknownValueError:
        speak("Sorry, I didn't catch that.")
        return ""
    except sr.RequestError:
        speak("Sorry, the speech service is unavailable.")
        return ""

def process_command(command):
    for appliance in appliances:
        if f"turn on {appliance}" in command:
            appliances[appliance] = True
            speak(f"{appliance} turned on.")
            print(f"{appliance}: ON")
        elif f"turn off {appliance}" in command:
            appliances[appliance] = False
            speak(f"{appliance} turned off.")
            print(f"{appliance}: OFF")
    if "status" in command:
        for appliance, state in appliances.items():
            status = "on" if state else "off"
            speak(f"{appliance} is {status}")
            print(f"{appliance}: {status}")

if __name__ == "__main__":
    speak("Voice control system activated.")
    while True:
        command = listen_command()
        if "exit" in command or "stop" in command:
            speak("Goodbye!")
            break
        process_command(command)
