import speech_recognition as sr
import datetime
import os

def transcribe_audio_to_text():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Please speak your medical notes...")
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)

    try:
        # Use Google Web Speech API
        text = recognizer.recognize_google(audio)
        print("Transcription:", text)
        return text
    except sr.UnknownValueError:
        print("Could not understand audio.")
        return ""
    except sr.RequestError:
        print("Could not request results from the speech recognition service.")
        return ""

def save_transcription(text, directory="transcriptions"):
    if not os.path.exists(directory):
        os.makedirs(directory)
    
    filename = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S") + ".txt"
    path = os.path.join(directory, filename)
    
    with open(path, "w") as file:
        file.write(text)
    
    print(f"Transcription saved to {path}")

if __name__ == "__main__":
    text = transcribe_audio_to_text()
    if text:
        save_transcription(text)
